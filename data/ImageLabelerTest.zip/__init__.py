"""
ImageLabeler Extension for MedICS.

This extension provides comprehensive image labeling capabilities
including automated analysis and quantitative measurements.
"""
from extensions.ImageLabeler.ExtensionMain import ImageLabelerExtension
__all__ = ['ImageLabelerExtension']