"""
VolumeLabeler Extension for MedICS.

This extension provides comprehensive volume labeling capabilities
including automated layer detection, analysis, and quantitative measurements.
"""
from typing import Any,Optional
from PySide6 import QtWidgets

from medics_extension_sdk import BaseExtension
from extensions.ImageLabeler.ImageLabelerMain import ImageLabelerMainClass

# Import utils module as referenced in original MedICS.py
try:
    from extensions.VolumeLabeler import utils
except ImportError as e:
    print(f"Warning: Could not import VolumeLabeler utils: {e}")
    utils = None


class ImageLabelerExtension(BaseExtension):
    """Extension wrapper for ImageLabeler toolbox."""

    def get_name(self) -> str:
        """Get extension name."""
        return "ImageLabeler"
    
    def get_version(self) -> str:
        """Get extension version."""
        return "1.0.0"
    
    def get_description(self) -> str:
        """Get extension description."""
        return "Comprehensive volume labeling tool with automated analysis and quantitative features"

    def get_author(self) -> str:
        """Get extension author."""
        return "MedICS Team"
    
    def get_category(self) -> str:
        """Get extension category."""
        return "Medical Imaging"


    def create_widget(self, parent: Optional[QtWidgets.QWidget] = None, **kwargs) -> QtWidgets.QWidget:
        """Create the extension's main widget."""
        # Create a regular widget instead of a dialog for tab display
        return ImageLabelerMainClass(parentWindow=parent, app_context=self.app_context, **kwargs)



# Export the extension class for discovery
__all__ = ['ImageLabelerExtension']